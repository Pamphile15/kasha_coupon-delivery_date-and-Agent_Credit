<?php

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
?>
<?php

        foreach ($skus as $key => $value) {
            if (($value['enabled'] == 'off') || ($value['product_page'] == 'off'))
                continue;
            $sku = get_post_meta($prod_id, $key);
             if (empty($sku[0]))
                continue;
            echo '<p><strong>' . $value['label'] . ':</strong>' . $sku[0] . '</p>';
        }