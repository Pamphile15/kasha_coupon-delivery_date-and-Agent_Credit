<div style="margin-top: 5px; margin-left: 10px; font-size: medium;">Order #<?php echo $order_id ?> Scan Log</div>
<div style="padding-left: 10px; padding-right: 10px;">
	<table class="table table-striped table-hover" >
		<thead></thead>
		<tbody style="vertical-align: top;">
			<tr style="/*width: 100%;*/">
				<th >Item</th>
				<th >Qty</th>
				<th>Qty Ovr</th>
				<th>Picked</th>
			</tr>
			<?php
			foreach ( $order_items[ 'products' ] as $key=>$value ) {
				//var_dump( $value );
				$name	 = $value[ 'name' ];
				$qty	 = $value[ 'qty' ];
				if ( isset( $value[ 'isparent' ] ) AND $value[ 'isparent' ] == 1 ) {
					$parent_qty = $value[ 'qty' ];
				}
				$bundle_class	 = isset( $value[ 'bundle_qty' ] ) ? 'bundle-element' : '';
				$qtyOvr			 = isset($pick_arr[$key]['is_ovr']) ? 'Y' : 'N';
				if ( $order_items[ 'picked' ] )
					$qtyPck			 = $value[ 'qty' ];
				else {
                                    //print_r($pick_arr[$key]);
                                    if (isset($pick_arr[$key][ 'qty' ]))
                                    $qtyPck			 = $pick_arr[$key][ 'qty' ];
                                    else
                                        $qtyPck=0;
                                    }
				echo
				'<tr>
					<td><div class="' . $bundle_class . '">' . $name . '</div></td>
					<td>' . $qty . '</td>
					<td>' . $qtyOvr . '</td>
					<td>' . $qtyPck . '</td>
				</tr>';
			}
			?>
		</tbody>
	</table>
</div>
