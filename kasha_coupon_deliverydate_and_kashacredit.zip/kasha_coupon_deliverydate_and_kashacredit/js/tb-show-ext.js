function resizeTB( width ) {
    var height = parseInt( jQuery( '#TB_window' ).css( 'height' ) );
    var top = parseInt( jQuery( '#TB_window' ).css( 'top' ) );
    var p = top - height / 2;
    if ( p < 20 )
        p = 20;

    var max_height = jQuery( window ).height() - 15;
    jQuery( '#TB_ajaxContent' ).attr( 'style', '' )
    jQuery( '#TB_window' ).css( { 'width': width } )
    jQuery( '#TB_window' ).css( 'max-height', max_height )
    jQuery( '#TB_window' ).css( 'top', p )
    jQuery( '#TB_window' ).css( 'overflow', 'auto' )
}