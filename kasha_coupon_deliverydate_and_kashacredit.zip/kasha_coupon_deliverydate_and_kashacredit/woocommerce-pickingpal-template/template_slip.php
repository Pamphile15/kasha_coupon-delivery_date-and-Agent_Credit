<link rel="stylesheet" type="text/css" href="<?php echo $url ?>/list.css">
<div class="page">


    <?php
    foreach ($orders as $order) {
        $order_number = ltrim($order->get_order_number(), '#');
        ?>
        <div>
            <?php
            $img = get_option('pickingpal-logo');
            if ($img) {
                ?>
                <img src="<?php echo $img ?>" class="logo">
                <?php
            }
            ?>
        </div>
        <div class="info">
            <?php echo nl2br(get_option('pickingpal-contact')); ?>
        </div>
        <div class="clearfix"></div>
        <div class="border-x"></div>
        <div class="info1">
            <table>
                <tr>
                    <td>
                        <h3><?php echo __('Billing Address', 'woocommerce-pickingpal') ?></h3>
                        <div class="info2">
                            <?php echo $order->get_formatted_billing_address(); ?>
                        </div>
                    </td>
                    <td>
                        <h3><?php echo __('Shipping Address', 'woocommerce-pickingpal') ?></h3>
                        <div class="info2">
                            <?php echo $order->get_formatted_shipping_address(); ?>
                        </div>
                    </td>
                    <td>
                        <h3><?php echo __('Shipping method', 'woocommerce-pickingpal') ?></h3>
                        <div class="info2">
                            <?php echo $order->get_shipping_method(); ?>
                        </div>
                    </td>
                </tr>
            </table>
        </div>
        <div class="barcode">
            <div><?php echo __('Invoice', 'woocommerce-pickingpal') ?> #<?php echo $order_number; ?></div>
            <font face="IDAutomationHC39M">(<?php echo $order_number; ?>)</font>
        </div>
        <h3 style="clear: both;"><?php
            echo __('Ship Date: ', 'woocommerce-pickingpal');
            echo current_time('m-d-Y');
            ?>
            &nbsp;&nbsp;&nbsp;
        <?php
            echo __('Order Date: ', 'woocommerce-pickingpal');
            echo date('m-d-Y',strtotime($order->order_date));?>
            </h3>
        <table class="products-list" style="">
            <tr class="item-line">
                <th class="header-list"><?php echo __('SKU-Product Name', 'woocommerce-pickingpal') ?></th>
                <th class="header-list"><?php echo __('Qty Ordered', 'woocommerce-pickingpal') ?></th>
                <th class="header-list"><?php echo __('Qty Shipped', 'woocommerce-pickingpal') ?></th>
                <!--<th class="header-list"><?php echo __('Qty Override', 'woocommerce-pickingpal') ?></th>-->
                <th class="header-list"><?php echo __('Qty Backordered', 'woocommerce-pickingpal') ?></th>
            </tr>
            <?php
            foreach ($order_items['products'] as $key => $value) {
                
                $name = $value['name'];
                $qty = $value['qty'];
                if (isset($value['isparent']) AND $value['isparent'] == 1) {
                    $parent_qty = $value['qty'];
                }
                $bundle_class = isset($value['bundle_qty']) ? 'bundle-element' : '';
                $qtyOvr = isset($pick_arr[$key]['is_ovr']) ? 'Y' : 'N';
                if ($order_items['picked'])
                    $qtyPck = $value['qty'];
                else {
                    //print_r($pick_arr[$key]);
                    if (isset($pick_arr[$key]['qty']))
                        $qtyPck = $pick_arr[$key]['qty'];
                    else
                        $qtyPck = 0;
                }
                if (isset($value['backordered']))
                    $qtyBack = $value['backordered'];
                else
                    $qtyBack = 0;
                
                ?>
                <tr class="item-line">
                    <td>
                        <div class="<?php echo $bundle_class ?>"><?= $name ?></div>		
                    </td>
                    <td>
                        <?php echo $qty ?>
                    </td>
                    <td>	
                        <?php echo $qtyPck ?>
                    </td>
                    <!--
                    <td>
                        <?php echo $qtyOvr; ?>
                    </td>
                    -->
                    <td>
                        <?php echo $qtyBack; ?>
                    </td>
                </tr>
                <?php
            }
            ?>
        </table>
        <p></p>
        <h3><?php echo __('Comments:', 'woocommerce-pickingpal') ?></h3>
        <div class="comments">
            <?php echo __('If shown, backordered items will ship as they become available.', 'woocommerce-pickingpal') ?>

        </div>
        <?php
    }
    ?>
	
</div>
<script>
   window.print()
</script>
